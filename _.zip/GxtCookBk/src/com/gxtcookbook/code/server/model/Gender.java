package com.gxtcookbook.code.server.model;

import com.extjs.gxt.ui.client.data.BeanModelTag;

public enum Gender implements BeanModelTag {
	MALE, FEMALE, UNKNOWN;
}
