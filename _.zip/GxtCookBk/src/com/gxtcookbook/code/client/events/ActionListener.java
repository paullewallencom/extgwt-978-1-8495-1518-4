package com.gxtcookbook.code.client.events;



public interface ActionListener {
	public void runAction();	
	
	public void actionPerformed();
}
