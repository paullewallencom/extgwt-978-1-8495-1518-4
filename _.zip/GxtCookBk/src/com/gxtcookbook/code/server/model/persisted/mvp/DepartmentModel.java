package com.gxtcookbook.code.server.model.persisted.mvp;

public interface DepartmentModel extends ModelType {

	public String getName();

	public void setName(String name);

	public String getCode();

	public void setCode(String code);
}
