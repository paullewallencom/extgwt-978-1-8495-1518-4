package com.gxtcookbook.code.client.icons.fugue.x32;

import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;



public interface FugueX32 extends ClientBundle {
	
	ImageResource folder();
	ImageResource document();

}
